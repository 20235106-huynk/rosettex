# Attention-Based Sequence Transduction with Residual Scaling

Alice Nguyen<sup>∗</sup>

Bob Smith†

November 18, 2026

## Abstract

We propose a simple network architecture based solely on attention mechanisms. Experiments on two translation tasks show that our model achieves 28.4 BLEU on English-to-German, improving over the best existing results by 2.0 BLEU, while requiring significantly less time to train.

## 1 Introduction

Recurrent networks [4] have been the dominant approach. In this work we show that attention alone suffices.

## 2 Method

Given an input sequence $x = (x_{1},\dots ,x_{n})$ with $x_{i}\in\mathbb{R}^{d}$ , we compute queries $Q = XW^{Q}$ , keys $K = XW^{K}$ and values $V = XW^{V}$ , where $W^{Q}\in\mathbb{R}^{d\times d_{k}}$ . The scaled dotproduct attention is

$$
\text {Attention} (Q, K, V) = \text {softmax} \left(\frac {Q K ^ {\top}}{\sqrt {d _ {k}}}\right) V.\tag{1}
$$

As shown in Eq. (1) , the factor $1 / \sqrt{d_k}$ prevents the softmax from saturating when $d_{k}$ is large, e.g. $d_{k} = 64$ Following [1, 2], we add residual connections so that $y = x + f(x)$ , and the loss is

$$
\mathcal {L} (\theta) = - \frac {1}{N} \sum_ {i = 1} ^ {N} \log p _ {\theta} (y _ {i} \mid x _ {i}) + \lambda \| \theta \| _ {2} ^ {2},\tag{2}
$$

with $\lambda = 0.01$ . The learning rate follows $\eta_t = d^{-0.5}$ min $(t^{-0.5}, t \cdot w^{-1.5})$ for warmup $w = 4000$ steps.<sup>1</sup>

## 3 Experiments

We train on WMT 2014 English–German, which contains about 4.5 million sentence pairs, and report BLEU in Table 1. Our model reaches 28.4 BLEU, outperforming the best previous result by 2.0 points while costing only $3.3\times 10^{18}$ FLOPs. Figure 1 shows that the validation loss decreases monotonically. The improvement is statistically significant $(p <   0.05)$ , although it may not generalize to low-resource pairs, as discussed in Section 2.

Table 1: BLEU scores and training cost on newstest2014.

<table><tbody><tr><td rowspan="2">Model</td><td rowspan="2">Size</td><td colspan="2">BLEU</td></tr><tr><td>EN-DE</td><td>EN-FR</td></tr><tr><td>ByteNet</td><td>1.2B</td><td>23.75</td><td>-</td></tr><tr><td>ConvS2S</td><td>0.9B</td><td>25.16</td><td>40.46</td></tr><tr><td>Ours (base)</td><td>65M</td><td>27.3</td><td>38.1</td></tr><tr><td>Ours (big)</td><td>213M</td><td>28.4</td><td>41.8</td></tr></tbody></table>

![](images/page_0_chart_18.jpg)

Figure 1: Validation loss during training of the big model.

Long paragraph to cross columns. The encoder is composed of a stack of $N = 6$ identical layers. Each layer has two sub-layers: the first is a multi-head self-attention mechanism, and the second is a simple, position-wise fully connected feed-forward network with inner dimension $d_{ff} = 2048$ We employ a residual connection around each of the two sub-layers, followed by layer normalization [3]. That is, the output of each sub-layer is $\operatorname{LayerNorm}(x + \operatorname{Sublayer}(x))$ . To facilitate these residual connections, all sub-layers in the model, as well as the embedding layers, produce outputs of dimension $d_{model} = 512$ . The decoder is also composed of a stack of $N = 6$ identical layers, and we modify the self-attention sub-layer to prevent positions from attending to subsequent positions; this masking ensures that predictions for position i can depend only on the known outputs at positions less than i.

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280">∗University of Example, alice@example.edu</span></small>

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280">†Example Labs, bob@example.com</span></small>

<small><span class="docvortex-page-footnote" data-block-type="page_footnote" style="color:#6b7280"><sup>1</sup>We found warmup essential; without it training diverged in 3 of 5 runs.</span></small>

## References

[1] A. Vaswani et al. Attention is all you need. NeurIPS, 2017.

[2] K. He et al. Deep residual learning for image recognition. CVPR, 2016.

[3] J. Ba, J. Kiros, G. Hinton. Layer normalization. arXiv:1607.06450, 2016.

[4] S. Hochreiter, J. Schmidhuber. Long short-term memory. Neural Computation, 9(8):1735–1780, 1997.